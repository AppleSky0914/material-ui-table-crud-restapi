const todos = (state = [], action) => {
    switch (action.type) {
      case 'SET_DATA':
        return action.data;
      case 'ADD_EMPLOYEE':
        return [
          ...state,
          action.employee
        ]
      default:
        return state
    }
  }
  
  export default todos