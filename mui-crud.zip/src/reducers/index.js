import { combineReducers } from 'redux'
import employees from './employees'
import visibilityFilter from './visibilityFilter'

export default combineReducers({
  employees,
  visibilityFilter
})