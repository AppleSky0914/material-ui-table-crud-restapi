import './App.css';
import RegistedEmployee from './pages/RegistedEmployee'
import CreateModal from './pages/CreateModal';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <CreateModal/>
      </header>
      <RegistedEmployee />
    </div>
  );
}

export default App;
