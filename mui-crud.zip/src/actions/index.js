let nextTodoId = 0
export const setEmployees = data => ({
  type: 'SET_DATA',
  data: data
})

export const addEmployee = employee => ({
  type: 'ADD_EMPLOYEE',
  employee: employee
})

export const setVisibilityFilter = filter => ({
  type: 'SET_VISIBILITY_FILTER',
  filter
})

export const toggleTodo = id => ({
  type: 'TOGGLE_TODO',
  id
})

export const VisibilityFilters = {
  SHOW_ALL: 'SHOW_ALL',
  SHOW_COMPLETED: 'SHOW_COMPLETED',
  SHOW_ACTIVE: 'SHOW_ACTIVE'
}

export const selectEmployees = (state) => state.employees;