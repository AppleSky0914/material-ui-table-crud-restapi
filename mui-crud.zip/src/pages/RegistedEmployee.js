import React, { useState, useEffect } from 'react';
// import PropTypes from 'prop-types';
import Box from '@mui/material/Box';
import Collapse from '@mui/material/Collapse';
import IconButton from '@mui/material/IconButton';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Typography from '@mui/material/Typography';
import Paper from '@mui/material/Paper';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import axios from 'axios';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/DeleteOutlined';
import { setEmployees } from '../actions';

import { useDispatch, useSelector } from 'react-redux'
import { selectEmployees } from '../actions'
import {
  useGridApiRef,
  DataGridPro,
  GridToolbarContainer,
  GridActionsCellItem,
} from '@mui/x-data-grid-pro';

const api = axios.create({
  baseURL: `http://localhost:3001`
})

// function createData(_id, name, email, phoneNumber, dateOfEmployment, dateOfBirth) {
//   return {
//     _id,
//     name,
//     email,
//     phoneNumber,
//     dateOfEmployment,
//     dateOfBirth,
//     history: [
//       {
//         date: '2020-01-05',
//         customerId: '11091700',
//         amount: 3,
//       },
//       {
//         date: '2020-01-02',
//         customerId: 'Anonymous',
//         amount: 1,
//       },
//     ],
//   };
// }

function Row(props) {
  const { row } = props;
  const [open, setOpen] = React.useState(false);

  return (
    <React.Fragment>
      <TableRow sx={{ '& > *': { borderBottom: 'unset' } }}>
        <TableCell style={{display: 'none'}} >{row._id}</TableCell>
        <TableCell>
          <IconButton
            aria-label="expand row"
            size="small"
            onClick={() => setOpen(!open)}
          >
            {open ? <KeyboardArrowUpIcon /> : <KeyboardArrowDownIcon />}
          </IconButton>
        </TableCell>
        <TableCell component="th" scope="row">
          {row.name}
        </TableCell>
        <TableCell align="right">{row.email}</TableCell>
        <TableCell align="right">{row.phoneNumber}</TableCell>
        <TableCell align="right">{row.dateOfEmployment}</TableCell>
        <TableCell align="right">{row.dateOfBirth}</TableCell>
        <TableCell align="right">
          <EditIcon style={{marginRight: '1vw'}} />
          <DeleteIcon style={{marginLeft: '1vw'}} />
        </TableCell>
      </TableRow>
      <TableRow>
        <TableCell style={{ paddingBottom: 0, paddingTop: 0 }} colSpan={6}>
          <Collapse in={open} timeout="auto" unmountOnExit>
            <Box sx={{ margin: 1 }}>
              <Typography variant="h6" gutterBottom component="div">
              HomeAddress
              </Typography>
              <Table size="small" aria-label="purchases">
                <TableHead>
                  <TableRow>
                    <TableCell>City</TableCell>
                    <TableCell>ZIPCode</TableCell>
                    <TableCell align="right">AddressLine1</TableCell>
                    <TableCell align="right">AddressLine2</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                    <TableRow >
                      <TableCell component="th" scope="row">
                        {row.homeAddress.city}
                      </TableCell>
                      <TableCell> {row.homeAddress.ZIPCode}</TableCell>
                      <TableCell align="right"> {row.homeAddress.addressLine1}</TableCell>
                      <TableCell align="right">
                      {row.homeAddress.addressLine2}
                      </TableCell>
                    </TableRow>
                </TableBody>
              </Table>
            </Box>
          </Collapse>
        </TableCell>
      </TableRow>
    </React.Fragment>
  );
}

// Row.propTypes = {
//   row: PropTypes.shape({
//     calories: PropTypes.number.isRequired,
//     carbs: PropTypes.number.isRequired,
//     fat: PropTypes.number.isRequired,
//     history: PropTypes.arrayOf(
//       PropTypes.shape({
//         amount: PropTypes.number.isRequired,
//         customerId: PropTypes.string.isRequired,
//         date: PropTypes.string.isRequired,
//       }),
//     ).isRequired,
//     name: PropTypes.string.isRequired,
//     price: PropTypes.number.isRequired,
//     protein: PropTypes.number.isRequired,
//   }).isRequired,
// };

// const rows = [
//   {id: 34, name: 'apple1', email: 'applesky19960914@gmail.com', phoneNumber: 159, homeAddress: { city: 'Singapore', ZIPCode: '40202', addressLine1: "Orchard Road International", addressLine2: "Orchard Road International"}, dateOfEmployment: '2020-07-10 15:00:00.000', dateOfBirth: '2020-07-10 15:00:00.000'},
//   createData(35,'apple2','applesky19960914@gmail.com', 159, '2020-07-10 15:00:00.000', '2020-07-10 15:00:00.000', 4.0, 3.99),
//   createData(36,'apple3','applesky19960914@gmail.com', 159, '2020-07-10 15:00:00.000', '2020-07-10 15:00:00.000', 4.0, 3.99),
//   createData(37,'apple4 ','applesky19960914@gmail.com', 159, '2020-07-10 15:00:00.000', '2020-07-10 15:00:00.000', 4.0, 3.99),
//   createData(38,'apple5','applesky19960914@gmail.com', 159, '2020-07-10 15:00:00.000', '2020-07-10 15:00:00.000', 4.0, 3.99),
// ];

export default function RegistedEmployee() {

  const dispatch = useDispatch();
  useEffect(() => { 
    api.get("/employees")
        .then(res => {      
            // console.log(res.data.employees)
            console.log(res.data.employees)
            
            dispatch(setEmployees(res.data.employees));
         })
         .catch(error=>{
             console.log("Error")
         })
  }, [])

  const employees = useSelector(selectEmployees)

  return (
    <TableContainer component={Paper}>
      <Table aria-label="collapsible table">
        <TableHead>
          <TableRow>
            <TableCell style={{display: 'none'}}>id </TableCell>
            <TableCell />
            <TableCell>Name</TableCell> 
            <TableCell align="right">Email</TableCell>
            <TableCell align="right">PhoneNumber</TableCell>
            <TableCell align="right">DateOfEmployment</TableCell>
            <TableCell align="right">DateOfBirth</TableCell>
            <TableCell align="right">Action</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {employees.map((row) => (
            <Row key={row._id} row={row} />
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
}