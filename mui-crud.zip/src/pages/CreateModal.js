import React, { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import TextField from '@mui/material/TextField';
import axios from 'axios';
import { WindowSharp } from '@mui/icons-material';
import { useDispatch } from 'react-redux';
import { addEmployee } from '../actions';

const style = {
  position: 'absolute',
  top: '5vh',
  left: '30vw',
  width: '40vw',
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};



export default function CreatModal() {
  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const [name, setName] = useState();
  const [email, setEmail] = useState();
  const [phoneNumber, setPhoneNumber] = useState();
  const [city, setCity] = useState();
  const [ZIPCode, seZIPCode] = useState();
  const [addressLine1, setAddressLine1] = useState();
  const [addressLine2, setAddressLine2] = useState();
  const [dateOfEmployment, setDateOfEmployment] = useState();
  const [dateOfBirth, setDateOfBirth] = useState();
  const dispatch = useDispatch();
  
  const handleSubmit = event => {
    event.preventDefault();
    var createEmployee = {
      name: name,
      email: email,
      phoneNumber: phoneNumber,
      homeAddress: {
        city: city,
        ZIPCode: ZIPCode,
        addressLine1: addressLine1,
        addressLine2: addressLine2
      },
      dateOfEmployment: dateOfEmployment,
      dateOfBirth: dateOfBirth
    }
    const jsonCreatedEmployee = JSON.stringify(createEmployee);
    console.log(jsonCreatedEmployee)
    axios({
      method: "post",
      url: "http://localhost:3001/employees",
      data: jsonCreatedEmployee,
      headers: { "Content-Type": "application/json" },
    })
      .then(function (response) {
        //handle success
        setOpen(false);
        dispatch(addEmployee(response.data));
      });
    // const url = 'https://jsonplaceholder.typicode.com/posts'
    // const requestOptions = {
    //     method: 'POST',
    //     headers: { 'Content-Type': 'application/json' },
    //     body: JSON.stringify({ email, password })
    // };
    // fetch(url, requestOptions)
    //     .then(response => console.log('Submitted successfully'))
    //     .catch(error => console.log('Form submit error', error))
  };

  return (
    <div>
    
      <Button onClick={handleOpen} variant="contained">Add Employee</Button>
        <Modal keepMounted open={open} onClose={handleClose} aria-labelledby="keep-mounted-model-title" aria-describedby="keep-mounted-modal-description">
          <Box sx={style}>

            <Box sx={{width:'40vw',maxWidth:'100%'}}>
              <h2>Create Employee</h2>
              <form onSubmit={handleSubmit} style={{width: "100%"}}>
              <TextField fullWidth  label="Name" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setName(e.target.value)}/>
              <TextField fullWidth  label="Email" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setEmail(e.target.value)}/>
              <TextField fullWidth  label="PhoneNumber" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setPhoneNumber(e.target.value)}/>
              <TextField fullWidth  label="City" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setCity(e.target.value)}/>
              <TextField fullWidth  label="ZIPCode" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => seZIPCode(e.target.value)}/>
              <TextField fullWidth  label="addressLine1" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setAddressLine1(e.target.value)}/>
              <TextField fullWidth  label="addressLine2" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setAddressLine2(e.target.value)}/>
              <TextField fullWidth  label="dateOfEmployment" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setDateOfEmployment(e.target.value)}/>
              <TextField fullWidth  label="dateOfBirth" ld="fullWidth" style={{marginTop: "1vh", marginBottom: "1vh"}} onChange={e => setDateOfBirth(e.target.value)}/>
              <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <Button type='submit' variant="contained" color="secondary" onClose={handleClose} style={{ marginRight: '5vw'}}>Save</Button>
              {/* <Button type='button' variant="contained" color="secondary" onClick={handleClose} style={{marginLeft: '5vw'}}>Close</Button> */}
              </div>
              </form>
            </Box>
          </Box>
        </Modal>
        
    </div>
  );
}